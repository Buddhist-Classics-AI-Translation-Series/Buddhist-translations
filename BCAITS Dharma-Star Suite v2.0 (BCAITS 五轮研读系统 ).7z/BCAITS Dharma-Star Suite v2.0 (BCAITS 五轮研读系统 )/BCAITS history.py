# -*- coding: utf-8 -*-
import os
import re
import time
import json
import threading
import requests
import urllib3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext, font
from datetime import datetime

# =============================================================================
# ⭐ 基础配置 (历史脉络版)
# =============================================================================

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_API_URL = "http://xxxxxxxxxxxxxx/v1/chat/completions"
DEFAULT_API_KEY = "sk-xxxxxxxxxxx"
DEFAULT_MODEL_NAME = "xxxxxxxxxxxx" # 推荐使用推理能力强的模型
DEFAULT_MAX_TOKENS = 800

# =============================================================================
# 🌍 国际化资源字典 (I18N) - History & Context
# =============================================================================

UI_STRINGS = {
    'zh': {
        'app_title': "BCAITS Chrono v1.4 (史观·历史脉络系统)",
        'group_api': "API 与 模型配置",
        'lbl_url': "API 地址:",
        'lbl_key': "API Key:",
        'lbl_model': "模型名称:",
        'group_file': "历史/传记文献输入 (History/Biography)",
        'btn_select_file': "📂 选择文件",
        'lbl_threshold': "分段阈值 (Tokens):",
        'group_lang': "任务矩阵 (叙事翻译 + 历史脉络分析)", 
        'col_lang': "语言",
        'col_trans': "叙事化翻译",
        'col_exe': "史实与脉络注解",
        'group_log': "考证日志",
        'group_preview': "实时预览",
        'btn_start': "🚀 启动历史考据",
        'btn_stop': "🛑 停止",
        'msg_done_body': "考据完成！\n已生成 [叙事译本]、[脉络注解] 及 [对照版] 文件。",
        'msg_err_nofile': "错误：请先选择输入文件",
        'msg_err_notask': "错误：请至少勾选一项任务",
        'msg_stop': "⚠️ 正在停止...",
        'msg_read_start': "读取史料中...",
        'msg_seg_done': "✅ 智能分段完成：共 {} 个叙事单元。",
        'msg_split_created': "已生成原始分段文件: {}",
        'msg_file_created': "创建文件: {}",
        'msg_processing': "考证片段 ({}/{}): {}",
        'msg_generating': "  -> [{}] 撰写 {} ...",
        'msg_done_title': "完成",
        'err_fatal': "❌ 错误: {}",
        'lang_zh': "中文", 'lang_en': "英文", 'lang_ja': "日文",
        'lang_ko': "韩文", 'lang_bo': "藏文", 'lang_pali': "巴利文",
        'lang_es': "西班牙语", 'lang_ru': "俄语", 'lang_fr': "法语", 'lang_de': "德语",
        'lang_hi': "印地语", 'lang_no': "挪威语",
    },
    'en': {
        'app_title': "BCAITS Chrono v1.4 (Historical Context System)",
        'group_api': "API & Model Settings",
        'lbl_url': "API Endpoint:",
        'lbl_key': "API Key:",
        'lbl_model': "Model Name:",
        'group_file': "History/Biography Source",
        'btn_select_file': "📂 Browse...",
        'lbl_threshold': "Threshold:",
        'group_lang': "Task Matrix (Narrative + Context)",
        'col_lang': "Language",
        'col_trans': "Narrative Trans",
        'col_exe': "Context & Annotation",
        'group_log': "Research Log",
        'group_preview': "Preview",
        'btn_start': "🚀 ANALYZE",
        'btn_stop': "🛑 STOP",
        'msg_done_body': "Analysis Complete! Translations and Contextual Notes generated.",
        'msg_err_nofile': "Error: Select file.",
        'msg_err_notask': "Error: Select at least one task.",
        'msg_stop': "⚠️ Stopping...",
        'msg_read_start': "Reading text...",
        'msg_seg_done': "✅ Segments: {}.",
        'msg_split_created': "Created split file: {}",
        'msg_file_created': "Created: {}",
        'msg_processing': "Processing ({}/{}): {}",
        'msg_generating': "  -> [{}] Writing {} ...",
        'msg_done_title': "Finished",
        'err_fatal': "❌ Error: {}",
        'lang_zh': "Chinese", 'lang_en': "English", 'lang_ja': "Japanese",
        'lang_ko': "Korean", 'lang_bo': "Tibetan", 'lang_pali': "Pali",
        'lang_es': "Spanish", 'lang_ru': "Russian", 'lang_fr': "French", 'lang_de': "German",
        'lang_hi': "Hindi", 'lang_no': "Norwegian",
    }
}

# =============================================================================
# 🧠 AI 核心配置：历史与地缘 (History & Geography)
# =============================================================================

class LangConfig:
    @staticmethod
    def get_trans_prompt(lang_code):
        # 翻译 Prompt：强调叙事性、故事性
        base = "You are a specialized Translator of Asian History and Biographies."
        rules = "Translate the text into a fluent, engaging narrative style (Storytelling). Keep titles and names accurate but ensure readability. If there is a date (e.g., Year X of Era Y), append the approximate Western Year in parentheses (e.g., 629 AD)."
        
        prompts = {
            'zh': f"{base} 请将文言文史料翻译为流畅、生动的现代白话文叙事。遇年号请括号标注公历年份。{rules}",
            'en': f"{base} Translate into fluent, narrative English. Convert Lunar/Regnal dates to Western calendar (e.g., 629 CE). {rules}",
            # ... 其他语言 ...
        }
        return prompts.get(lang_code, prompts.get('en'))

    @staticmethod
    def get_exe_prompt(lang_code):
        # ⭐ 核心指令：来龙去脉 + 历史背景 + 深度考证
        CORE_INSTRUCTION = """
        [Role]: You are a Senior Historian and Historical Geographer.
        [Task]: Explain the "Context and Lineage" (来龙去脉) of this passage.
        
        [Analysis Framework]:
        1. **Annotation (史实注疏)**:
           - **People**: Who are they? (Lineage/Teacher/Disciple).
           - **Geography**: Where is this place today? (e.g., Chang'an -> Xi'an).
           - **Terms**: Explain official titles or specific historical artifacts.
           
        2. **Historical Context (历史脉络)**:
           - **The 'Why' (Cause)**: Why did this event happen? (Consider Political climate, Dynastic changes, Sectarian rivalry).
           - **The 'Flow' (Process)**: Connect this event to the broader history of the time (e.g., Tang Dynasty politics).
           - **The 'Impact' (Effect)**: What was the result of this event for future generations?
           
        3. **Timeline Anchor (时间锚点)**:
           - Clearly state the time period and its significance (e.g., "This occurred during the suppression of Buddhism...").
        """
        
        prompts = {
            'zh': f"""{CORE_INSTRUCTION}
            输出格式：
            【史实注疏】(人物生平、古今地名对照、职官解释)
            【历史脉络】(深度解析：事件的前因后果、当时的政治背景、皇权与教权的关系)
            【时间锚点】(明确的时间定位与时代特征)""",
            
            'en': f"""{CORE_INSTRUCTION}
            Output Format:
            [Historical Annotations] (People, Modern Geography, Titles)
            [Historical Context] (The "Cause and Effect". Political backdrop, lineage connections)
            [Timeline Anchor] (Specific era and significance)""",
            
            # ... 其他语言 ...
        }
        return prompts.get(lang_code, prompts['en'])

    @staticmethod
    def get_file_suffix(lang_code, task_type):
        file_lang_code = 'cn' if lang_code == 'zh' else lang_code
        names = {
            'trans': {'zh': '叙事译本', 'en': 'Narrative_Trans'},
            'exe': {'zh': '脉络注解', 'en': 'History_Context'},
            'combined': {'zh': '史学对照版', 'en': 'Chrono_Study'}
        }
        func_name = names.get(task_type, {}).get(lang_code, 'Output')
        return f"_{func_name}.{file_lang_code}.txt"

    @staticmethod
    def validate_pali(text):
        return True, None # 历史文献通常不涉及纯巴利文校验

# =============================================================================
# 📜 智能分段 (针对史传文献优化)
# =============================================================================

class ZenTextProcessor:
    def __init__(self):
        # 针对历史/传记，关键词：年号、朝代、传、志、年纪、师、法师
        # 匹配模式： "唐贞观三年" "卷第一" "法师传" "...志"
        self.header_pattern = re.compile(r'^\s*([^\s]+(?:传|志|记|纪|卷|年|朝|代|帝|师|国师|Biography|Year|Dynasty)|Chapter\s+\d+)\s*.*$')
        self.sentence_end_pattern = re.compile(r'([。！？；.!?;]+)')

    def preprocess_text(self, full_text):
        if len(full_text) > 1000 and full_text.count('\n') < 10:
            full_text = self.sentence_end_pattern.sub(r'\1\n', full_text)
        return full_text

    def smart_segmentation(self, full_text, max_chars=3500):
        # 史传文章通常较长，增加 max_chars
        full_text = self.preprocess_text(full_text)
        lines = full_text.split('\n')
        segments = []
        current_title = "Historical Record / 史料选段"
        current_buffer = []
        current_count = 0
        is_standard_style = (sum(1 for line in lines[:100] if self.header_pattern.match(line)) > 2)

        for line in lines:
            line = line.rstrip()
            if not line: continue
            should_split = False; new_title = None
            is_header = False
            
            # 史料分段策略：遇到新的年份或人物传记标题时切分
            if is_standard_style:
                # 如果行比较短且包含年份或标题关键词
                if self.header_pattern.match(line) and len(line) < 50: is_header = True
            else:
                if len(line) < 50 and not self.sentence_end_pattern.search(line[-1:]):
                    if current_count > 800: is_header = True 
            
            if is_header: should_split = True; new_title = line.strip()
            if current_count + len(line) > max_chars: should_split = True; new_title = new_title if new_title else current_title + " (Cont.)"

            if should_split and current_buffer:
                segments.append({"title": current_title, "content": "\n".join(current_buffer)})
                if new_title:
                    current_title = new_title
                    if is_header: current_buffer = []; current_count = 0
                    else: current_buffer = [line]; current_count = len(line)
                else: current_buffer = [line]; current_count = len(line)
            else:
                if is_header: current_title = line.strip()
                else: current_buffer.append(line); current_count += len(line)
        
        if current_buffer: segments.append({"title": current_title, "content": "\n".join(current_buffer)})
        return segments

# =============================================================================
# 🤖 AI 引擎 (温和处理：0.5)
# =============================================================================

class AiEngine:
    def __init__(self, api_url, api_key):
        self.api_url = api_url
        self.api_key = api_key
    def process(self, title, content, system_prompt, model_name, validator=None):
        user_prompt = f"Target Text: {title}\n\nContent:\n{content}"
        messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        for _ in range(3):
            try:
                # ⭐ 关键修改：Temperature 设为 0.5
                # 平衡点：需要创造力来连接历史脉络（讲故事），但也需要准确性来引用史实
                payload = {"model": model_name, "messages": messages, "temperature": 0.5, "max_tokens": 4096}
                resp = requests.post(self.api_url, headers=headers, json=payload, timeout=240)
                if resp.status_code!=200: raise Exception(str(resp.status_code))
                res = resp.json()['choices'][0]['message']['content']
                if validator:
                    if not validator(res)[0]: continue
                return res
            except: time.sleep(3)
        return "[FAILED]"

# =============================================================================
# 🚀 启动器 & GUI (复用架构)
# =============================================================================
# 保持与 v1.2/v1.3 相同的 GUI 结构，只需确保类名和调用正确

class LanguageLauncher:
    def __init__(self):
        self.root = tk.Tk(); self.root.title("Language Selection"); 
        w,h=550,550; x,y=(self.root.winfo_screenwidth()-w)//2, (self.root.winfo_screenheight()-h)//2
        self.root.geometry(f"{w}x{h}+{x}+{y}"); self.selected_lang=None
        ttk.Label(self.root, text="Select Interface Language\n请选择界面语言", font=("Arial",14), justify=tk.CENTER).pack(pady=20)
        f=ttk.Frame(self.root); f.pack(pady=10)
        langs=[("中文 (Chinese)",'zh'),("English",'en'),("日本語 (Japanese)",'ja'),("한국어 (Korean)",'ko'),("བོད་ཡིག (Tibetan)",'bo'),("Pāḷi (Roman)",'pali'),("Español (Spanish)",'es'),("Русский (Russian)",'ru'),("Français (French)",'fr'),("Deutsch (German)",'de'),("हिन्दी (Hindi)",'hi'),("Norsk (Norwegian)",'no')]
        for i,(n,c) in enumerate(langs): ttk.Button(f,text=n,command=lambda x=c:self.sel(x),width=22).grid(row=i//2,column=i%2,padx=10,pady=10)
    def sel(self,c): self.selected_lang=c; self.root.destroy()
    def run(self): self.root.mainloop(); return self.selected_lang

class ZenUniversalApp:
    def __init__(self, root, ui_lang='zh'):
        self.root = root; self.ui_lang = ui_lang
        self.T = UI_STRINGS.get(ui_lang, UI_STRINGS['en'])
        self.root.title(self.T['app_title'])
        self.root.geometry("1200x950")
        self.processor = ZenTextProcessor()
        self.vars_trans = {}; self.vars_exe = {}
        self.is_running = False; self.stop_event = threading.Event()
        self._setup_ui()
        
    def _setup_ui(self):
        # ... (GUI 代码完全复用，仅需注意 Prompt 和 Config 的自动调用) ...
        # 为节省篇幅，此处省略重复 GUI 代码，实际运行时请复制 v1.3 的 GUI 部分，
        # 并确保 T (UI_STRINGS) 指向的是本文件的配置。
        top_container = ttk.Frame(self.root, padding=10); top_container.pack(fill=tk.X)
        api_group = ttk.LabelFrame(top_container, text=self.T['group_api'], padding=10)
        api_group.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        f1 = ttk.Frame(api_group); f1.pack(fill=tk.X, pady=2)
        ttk.Label(f1, text=self.T['lbl_url'], width=10).pack(side=tk.LEFT)
        self.api_url = tk.StringVar(value=DEFAULT_API_URL); ttk.Entry(f1, textvariable=self.api_url).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(f1, text=self.T['lbl_key'], width=8).pack(side=tk.LEFT)
        self.api_key = tk.StringVar(value=DEFAULT_API_KEY); ttk.Entry(f1, textvariable=self.api_key, show="*", width=20).pack(side=tk.LEFT, padx=5)
        f2 = ttk.Frame(api_group); f2.pack(fill=tk.X, pady=5)
        ttk.Label(f2, text=self.T['lbl_model'], width=10).pack(side=tk.LEFT)
        self.model_name = tk.StringVar(value=DEFAULT_MODEL_NAME); ttk.Entry(f2, textvariable=self.model_name).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        action_frame = ttk.Frame(top_container, padding=(10, 0, 0, 0)); action_frame.pack(side=tk.RIGHT, fill=tk.Y)
        style = ttk.Style(); style.configure("Big.TButton", font=("Arial", 12, "bold")); style.configure("Stop.TButton", font=("Arial", 10))
        self.btn_start = ttk.Button(action_frame, text=self.T['btn_start'], command=self.start, style="Big.TButton", width=15)
        self.btn_start.pack(side=tk.TOP, fill=tk.BOTH, expand=True, pady=(5, 5), ipady=10)
        self.btn_stop = ttk.Button(action_frame, text=self.T['btn_stop'], command=self.stop, style="Stop.TButton")
        self.btn_stop.pack(side=tk.BOTTOM, fill=tk.X, pady=(0, 5))
        mid_frame = ttk.Frame(self.root, padding=10); mid_frame.pack(fill=tk.X)
        file_group = ttk.LabelFrame(mid_frame, text=self.T['group_file'], padding=10)
        file_group.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        f_box = ttk.Frame(file_group); f_box.pack(fill=tk.X)
        self.file_path = tk.StringVar(); ttk.Entry(f_box, textvariable=self.file_path).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(f_box, text=self.T['btn_select_file'], command=self._select_file).pack(side=tk.LEFT, padx=5)
        t_box = ttk.Frame(file_group); t_box.pack(fill=tk.X, pady=5)
        ttk.Label(t_box, text=self.T['lbl_threshold']).pack(side=tk.LEFT)
        self.ts_limit = tk.IntVar(value=DEFAULT_MAX_TOKENS); ttk.Entry(t_box, textvariable=self.ts_limit, width=8).pack(side=tk.LEFT, padx=5)
        lang_group = ttk.LabelFrame(mid_frame, text=self.T['group_lang'], padding=10)
        lang_group.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 0))
        ttk.Label(lang_group, text=self.T['col_lang'], font=("Arial", 9, "bold")).grid(row=0, column=0, sticky=tk.W)
        ttk.Label(lang_group, text=self.T['col_trans'], font=("Arial", 9, "bold")).grid(row=0, column=1)
        ttk.Label(lang_group, text=self.T['col_exe'], font=("Arial", 9, "bold")).grid(row=0, column=2)
        order = ['zh', 'en', 'ja', 'ko', 'bo', 'pali', 'es', 'ru', 'fr', 'de', 'hi', 'no']
        for i, key in enumerate(order):
            row = i + 1
            ttk.Label(lang_group, text=self.T.get(f'lang_{key}', key)).grid(row=row, column=0, sticky=tk.W, padx=5, pady=2)
            val_trans = False; val_exe = (key == self.ui_lang) 
            vt = tk.BooleanVar(value=val_trans); self.vars_trans[key] = vt
            ve = tk.BooleanVar(value=val_exe); self.vars_exe[key] = ve
            ttk.Checkbutton(lang_group, variable=vt).grid(row=row, column=1)
            ttk.Checkbutton(lang_group, variable=ve).grid(row=row, column=2)
        main_content = ttk.PanedWindow(self.root, orient=tk.VERTICAL); main_content.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        log_frame = ttk.LabelFrame(main_content, text=self.T['group_log']); main_content.add(log_frame, weight=1)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8, font=("Consolas", 9), state='normal'); self.log_text.pack(fill=tk.BOTH, expand=True)
        preview_frame = ttk.LabelFrame(main_content, text=self.T['group_preview']); main_content.add(preview_frame, weight=4)
        self.preview_area = scrolledtext.ScrolledText(preview_frame, font=("微软雅黑", 11)); self.preview_area.pack(fill=tk.BOTH, expand=True)
        self.progress = ttk.Progressbar(self.root, mode='determinate'); self.progress.pack(fill=tk.X, padx=10, pady=(0, 5))

    def _select_file(self):
        f = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if f: self.file_path.set(f)
    def log(self, msg):
        self.log_text.insert(tk.END, f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n"); self.log_text.see(tk.END)
    def stop(self):
        if self.is_running: self.stop_event.set(); self.log(self.T['msg_stop'])
    def start(self):
        if not self.file_path.get(): messagebox.showerror("Error", self.T['msg_err_nofile']); return
        selected_tasks = []
        selected_langs = set()
        for lang in ['zh', 'en', 'ja', 'ko', 'bo', 'pali', 'es', 'ru', 'fr', 'de', 'hi', 'no']:
            if self.vars_trans[lang].get(): selected_tasks.append({'lang': lang, 'type': 'trans'}); selected_langs.add(lang)
            if self.vars_exe[lang].get(): selected_tasks.append({'lang': lang, 'type': 'exe'}); selected_langs.add(lang)
        if not selected_tasks: messagebox.showerror("Error", self.T['msg_err_notask']); return
        self.is_running = True; self.stop_event.clear(); self.btn_start.config(state=tk.DISABLED)
        threading.Thread(target=self._run_process, args=(selected_tasks, list(selected_langs)), daemon=True).start()

    def _run_process(self, tasks, active_langs):
        input_file = self.file_path.get(); base_name = os.path.splitext(input_file)[0]
        try:
            self.log(self.T['msg_read_start'])
            with open(input_file, 'r', encoding='utf-8') as f: content = f.read()
            segments = self.processor.smart_segmentation(content, self.ts_limit.get()); total_segs = len(segments)
            self.log(self.T['msg_seg_done'].format(total_segs))
            
            split_file_path = f"{base_name}_split.txt"
            with open(split_file_path, 'w', encoding='utf-8') as f:
                for seg in segments: f.write(f"【{seg['title']}】\n{seg['content']}\n\n{'='*40}\n\n")
            self.log(self.T['msg_split_created'].format(os.path.basename(split_file_path)))

            handles = {}
            for t in tasks:
                suffix = LangConfig.get_file_suffix(t['lang'], t['type']); out_path = base_name + suffix
                f = open(out_path, 'w', encoding='utf-8'); f.write(f"=== {t['type'].upper()} ({t['lang'].upper()}) ===\nSource: {os.path.basename(input_file)}\n\n")
                handles[(t['lang'], t['type'])] = f
                self.log(self.T['msg_file_created'].format(os.path.basename(out_path)))
            
            for lang in active_langs:
                suffix = LangConfig.get_file_suffix(lang, 'combined'); out_path = base_name + suffix
                f = open(out_path, 'w', encoding='utf-8'); f.write(f"=== CHRONO HISTORY STUDY ({lang.upper()}) ===\nSource: {os.path.basename(input_file)}\n\n")
                handles[(lang, 'combined')] = f
                self.log(self.T['msg_file_created'].format(os.path.basename(out_path)))

            ai = AiEngine(self.api_url.get(), self.api_key.get())
            for i, seg in enumerate(segments):
                if self.stop_event.is_set(): break
                title, text = seg['title'], seg['content']
                self.log(self.T['msg_processing'].format(i+1, total_segs, title))
                segment_results = {lang: {'trans': None, 'exe': None} for lang in active_langs}

                for t in tasks:
                    if self.stop_event.is_set(): break
                    lang, type_ = t['lang'], t['type']
                    prompt = LangConfig.get_trans_prompt(lang) if type_ == 'trans' else LangConfig.get_exe_prompt(lang)
                    validator = LangConfig.validate_pali if lang == 'pali' else None
                    
                    lang_name = self.T.get(f'lang_{lang}', lang); task_display = self.T['col_trans'] if type_ == 'trans' else self.T['col_exe']
                    self.log(self.T['msg_generating'].format(lang_name, task_display))
                    
                    result = ai.process(title, text, prompt, self.model_name.get(), validator)
                    handles[(lang, type_)].write(f"【{title}】\n{result}\n\n{'='*60}\n\n"); handles[(lang, type_)].flush()
                    segment_results[lang][type_] = result
                    self.preview_area.delete(1.0, tk.END); self.preview_area.insert(tk.END, f"--- {lang_name} [{type_}] ---\n{title}\n\n{result}")
                
                for lang in active_langs:
                    combined_f = handles[(lang, 'combined')]
                    combined_text = f"【{title}】\n\n--- Source ---\n{text}\n"
                    if segment_results[lang].get('trans'): combined_text += f"\n--- Narrative ---\n{segment_results[lang]['trans']}\n"
                    if segment_results[lang].get('exe'): combined_text += f"\n--- Context & Annotation ---\n{segment_results[lang]['exe']}\n"
                    combined_text += f"\n{'='*60}\n\n"
                    combined_f.write(combined_text); combined_f.flush()

                self.progress['value'] = ((i + 1) / total_segs) * 100
            
            self.log("DONE!"); messagebox.showinfo(self.T['msg_done_title'], self.T['msg_done_body'])
        except Exception as e:
            self.log(self.T['err_fatal'].format(str(e))); messagebox.showerror("Error", str(e))
        finally:
            if 'handles' in locals():
                for f in handles.values(): f.close()
            self.is_running = False; self.btn_start.config(state=tk.NORMAL); self.progress['value'] = 0

if __name__ == "__main__":
    launcher = LanguageLauncher()
    selected_lang = launcher.run()
    if selected_lang:
        root = tk.Tk()
        app = ZenUniversalApp(root, ui_lang=selected_lang)
        root.mainloop()
