# -*- coding: utf-8 -*-
"""
佛经文本清洗工具 (稳定版)
功能：批量提取 g2.0f.txt 文件中的现代汉语部分
修复：解决了线程冲突导致的无法启动或卡死问题
"""

import os
import re
import sys
import threading
import queue
import time
from pathlib import Path

# 尝试导入 tkinter，如果环境缺失则提示
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except ImportError:
    print("❌ 错误：您的 Python 环境未安装 tkinter 模块，无法显示图形界面。")
    input("按回车键退出...")
    sys.exit(1)

class TextCleanerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("佛经文本清洗工具 v2.0 (稳定版)")
        self.root.geometry("750x600")
        # 设置最小尺寸，防止窗口过小
        self.root.minsize(600, 500)
        
        # 消息队列，用于线程通信
        self.msg_queue = queue.Queue()
        
        # 变量
        self.selected_dir = tk.StringVar()
        self.is_processing = False
        
        self.create_widgets()
        
        # 启动队列监听循环
        self.root.after(100, self.process_queue_msg)

    def create_widgets(self):
        # 主容器
        main_frame = tk.Frame(self.root, padx=10, pady=10)
        main_frame.pack(fill="both", expand=True)

        # 1. 标题
        title_label = tk.Label(
            main_frame, 
            text="佛经文本清洗工具", 
            font=("微软雅黑", 16, "bold"),
            fg="#2C3E50"
        )
        title_label.pack(pady=(0, 15))
        
        # 2. 说明区
        desc_frame = tk.LabelFrame(main_frame, text=" 使用说明 ", font=("微软雅黑", 10), padx=10, pady=10)
        desc_frame.pack(fill="x", pady=(0, 15))
        
        desc_text = (
            "1. 点击【浏览】选择包含文件的文件夹\n"
            "2. 程序会自动查找以 g2.0f.txt 结尾的文件\n"
            "3. 自动提取【现代汉语翻译】内容\n"
            "4. 生成新文件：原文件名.xdhy.g2.0f.txt"
        )
        tk.Label(desc_frame, text=desc_text, justify="left", font=("微软雅黑", 9)).pack(anchor="w")
        
        # 3. 目录选择区
        dir_frame = tk.Frame(main_frame)
        dir_frame.pack(fill="x", pady=(0, 15))
        
        tk.Label(dir_frame, text="目标目录：", font=("微软雅黑", 10)).pack(side="left")
        
        self.dir_entry = tk.Entry(
            dir_frame, 
            textvariable=self.selected_dir, 
            font=("微软雅黑", 9),
            state="readonly"
        )
        self.dir_entry.pack(side="left", fill="x", expand=True, padx=5)
        
        btn_browse = tk.Button(
            dir_frame, 
            text="📂 浏览...", 
            command=self.browse_directory,
            bg="#3498DB", fg="white", font=("微软雅黑", 9),
            relief="flat", padx=10
        )
        btn_browse.pack(side="left")
        
        # 4. 日志区
        log_frame = tk.Frame(main_frame)
        log_frame.pack(fill="both", expand=True, pady=(0, 10))
        
        tk.Label(log_frame, text="处理日志：", font=("微软雅黑", 9)).pack(anchor="w")
        
        scrollbar = tk.Scrollbar(log_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.log_text = tk.Text(
            log_frame,
            height=10,
            font=("Consolas", 9),
            bg="#F8F9FA",
            state="disabled", # 初始只读
            yscrollcommand=scrollbar.set
        )
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.log_text.yview)
        
        # 5. 进度条
        self.progress_bar = ttk.Progressbar(main_frame, mode='determinate')
        self.progress_bar.pack(fill="x", pady=(0, 15))
        
        # 6. 按钮区
        btn_frame = tk.Frame(main_frame)
        btn_frame.pack()
        
        self.start_btn = tk.Button(
            btn_frame,
            text="▶ 开始处理",
            command=self.start_processing,
            bg="#27AE60", fg="white",
            font=("微软雅黑", 11, "bold"),
            width=15, height=2,
            relief="flat"
        )
        self.start_btn.pack(side="left", padx=20)
        
        self.exit_btn = tk.Button(
            btn_frame,
            text="退出程序",
            command=self.root.quit,
            bg="#95A5A6", fg="white",
            font=("微软雅黑", 11),
            width=10, height=2,
            relief="flat"
        )
        self.exit_btn.pack(side="left", padx=20)

    def process_queue_msg(self):
        """
        主线程定时检查队列，更新UI
        这是解决界面卡死/崩溃的关键！
        """
        try:
            while True:
                # 不阻塞地获取消息
                msg_type, data = self.msg_queue.get_nowait()
                
                if msg_type == "log":
                    self.log_text.config(state="normal")
                    self.log_text.insert(tk.END, data)
                    self.log_text.see(tk.END)
                    self.log_text.config(state="disabled")
                elif msg_type == "progress_max":
                    self.progress_bar['maximum'] = data
                elif msg_type == "progress_val":
                    self.progress_bar['value'] = data
                elif msg_type == "finish":
                    messagebox.showinfo("完成", data)
                    self.start_btn.config(state="normal")
                    self.is_processing = False
                elif msg_type == "error":
                    messagebox.showerror("错误", data)
                    self.start_btn.config(state="normal")
                    self.is_processing = False
                    
                self.msg_queue.task_done()
        except queue.Empty:
            pass
        
        # 每100ms再次检查
        self.root.after(100, self.process_queue_msg)

    def log(self, message):
        """发送日志消息到队列"""
        self.msg_queue.put(("log", message))

    def browse_directory(self):
        if self.is_processing: return
        path = filedialog.askdirectory()
        if path:
            self.selected_dir.set(path)
            self.log_text.config(state="normal")
            self.log_text.delete(1.0, tk.END)
            self.log_text.config(state="disabled")
            self.log(f"已选择目录：{path}\n准备就绪。\n")

    def extract_content(self, text):
        """提取核心逻辑"""
        # 1. 尝试标准匹配
        pattern = r'【现代汉语翻译】(.*?)(?=【English Translation】|$)'
        matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
        
        if not matches:
            # 2. 尝试无括号匹配
            pattern = r'现代汉语翻译】?(.*?)(?=English Translation|$)'
            matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
            
        if not matches:
            return None
            
        # 清洗数据
        results = []
        for m in matches:
            clean_text = m.strip()
            # 去除常见标题头
            clean_text = re.sub(r'^现代汉语译本[:：]?\s*', '', clean_text, flags=re.MULTILINE)
            # 去除分割线
            clean_text = re.sub(r'-{5,}', '', clean_text)
            # 压缩多余空行
            clean_text = re.sub(r'\n{3,}', '\n\n', clean_text)
            
            if len(clean_text) > 10: # 太短的忽略
                results.append(clean_text)
                
        return '\n\n'.join(results).strip() if results else None

    def start_processing(self):
        directory = self.selected_dir.get()
        if not directory:
            messagebox.showwarning("提示", "请先选择目录！")
            return
            
        self.is_processing = True
        self.start_btn.config(state="disabled")
        self.log_text.config(state="normal")
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state="disabled")
        
        # 启动后台线程
        threading.Thread(target=self.worker_thread, args=(directory,), daemon=True).start()

    def worker_thread(self, directory):
        """后台工作线程"""
        self.log("="*40 + "\n")
        self.log("开始扫描文件...\n")
        self.log("="*40 + "\n")
        
        target_files = []
        try:
            for root, dirs, files in os.walk(directory):
                for file in files:
                    # 匹配逻辑：包含 g2.0f.txt 且 不包含 xdhy
                    if 'g2.0f.txt' in file and 'xdhy' not in file:
                        target_files.append(os.path.join(root, file))
        except Exception as e:
            self.msg_queue.put(("error", f"扫描目录出错：{e}"))
            return

        total = len(target_files)
        self.log(f"扫描完成，找到 {total} 个待处理文件。\n\n")
        
        if total == 0:
            self.msg_queue.put(("finish", "未找到符合条件的文件。\n请确认目录下有 .g2.0f.txt 文件。"))
            return

        self.msg_queue.put(("progress_max", total))
        
        success = 0
        fail = 0
        
        for i, filepath in enumerate(target_files):
            filename = os.path.basename(filepath)
            self.log(f"[{i+1}/{total}] 处理：{filename} ... ")
            
            try:
                # 尝试多种编码读取
                content = None
                encodings = ['utf-8', 'gbk', 'utf-16', 'gb18030']
                for enc in encodings:
                    try:
                        with open(filepath, 'r', encoding=enc) as f:
                            content = f.read()
                        break
                    except:
                        continue
                
                if content is None:
                    self.log("❌ 读取失败(编码未知)\n")
                    fail += 1
                    continue
                    
                result = self.extract_content(content)
                
                if result:
                    # 生成新文件名
                    new_name = filename.replace('g2.0f.txt', 'xdhy.g2.0f.txt')
                    new_path = os.path.join(os.path.dirname(filepath), new_name)
                    
                    with open(new_path, 'w', encoding='utf-8') as f:
                        f.write(result)
                    
                    self.log("✅ 成功\n")
                    success += 1
                else:
                    self.log("⚠️ 未找到现代汉语部分\n")
                    fail += 1
                    
            except Exception as e:
                self.log(f"❌ 出错: {e}\n")
                fail += 1
            
            self.msg_queue.put(("progress_val", i+1))
            # 稍作延时，让界面有机会刷新
            time.sleep(0.01)
            
        self.log("\n" + "="*40 + "\n")
        self.log(f"处理完毕！\n成功：{success}  失败：{fail}\n")
        self.msg_queue.put(("finish", f"处理完成！\n成功：{success}\n失败：{fail}"))

def main():
    # 异常捕获，防止闪退
    try:
        root = tk.Tk()
        app = TextCleanerGUI(root)
        root.mainloop()
    except Exception as e:
        print(f"❌ 程序启动发生严重错误:\n{e}")
        input("\n按回车键退出...")

if __name__ == "__main__":
    main()
