def merge_txt_files():
   # 获取输入文件路径
   file1_path = input("请输入第一个txt文件的路径: ")
   file2_path = input("请输入第二个txt文件的路径: ")
   output_path = input("请输入合并后文件的保存路径: ")

   try:
       # 读取第一个文件
       with open(file1_path, 'r', encoding='utf-8') as f1:
           content1 = f1.read()

       # 读取第二个文件
       with open(file2_path, 'r', encoding='utf-8') as f2:
           content2 = f2.read()

       # 合并内容
       merged_content = content1 + '\n' + content2

       # 写入新文件
       with open(output_path, 'w', encoding='utf-8') as out_file:
           out_file.write(merged_content)

       print(f"文件已成功合并并保存到: {output_path}")

   except FileNotFoundError:
       print("错误: 找不到指定的文件")
   except Exception as e:
       print(f"发生错误: {str(e)}")

if __name__ == "__main__":
   merge_txt_files()
