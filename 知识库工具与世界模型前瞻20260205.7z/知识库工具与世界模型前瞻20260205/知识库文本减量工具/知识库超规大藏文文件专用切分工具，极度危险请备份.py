import os
import math
import logging
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox

# ========= 日志配置 =========
log_filename = f"藏文切分日志_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ========= 基础函数 =========
def convert_mb_to_bytes(mb):
    """将兆字节转换为字节"""
    return mb * 1024 * 1024

# ========= 核心藏文句号切分逻辑 =========
def split_tibetan_text(text):
    """
    按藏文句号།切分文本
    避免在同一段话中乱切
    """
    parts = []
    sentences = text.split("།")
    buffer = ""
    for sentence in sentences:
        buffer += sentence + "།"
        # 若句子够长或遇到换行，可视为自然段
        if len(buffer.encode('utf-8')) > 800 or "\n" in sentence:
            parts.append(buffer.strip())
            buffer = ""
    if buffer.strip():
        parts.append(buffer.strip())
    return parts

# ========= 文件切分函数 =========
def split_text_file(file_path, max_bytes_per_part):
    """按藏文句号切分单个文件"""
    original_filename = os.path.basename(file_path)
    base_name, ext = os.path.splitext(original_filename)
    output_dir = os.path.dirname(file_path)

    logger.info(f"开始切分文件: '{original_filename}'")

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()

        # 按藏文句号分段
        tibetan_parts = split_tibetan_text(text)

        created_files = []
        buffer = ""
        part_count = 0

        for section in tibetan_parts:
            buffer += section + "\n"
            if len(buffer.encode('utf-8')) >= max_bytes_per_part:
                part_count += 1
                new_file = os.path.join(output_dir, f"{base_name} ({part_count}){ext}")
                with open(new_file, 'w', encoding='utf-8') as out:
                    out.write(buffer)
                created_files.append(new_file)
                logger.info(f"生成分段文件: {new_file}")
                buffer = ""

        if buffer.strip():
            part_count += 1
            new_file = os.path.join(output_dir, f"{base_name} ({part_count}){ext}")
            with open(new_file, 'w', encoding='utf-8') as out:
                out.write(buffer)
            created_files.append(new_file)
            logger.info(f"生成分段文件: {new_file}")

        if created_files:
            os.remove(file_path)
            logger.info(f"原始文件 '{original_filename}' 已删除。")
        return created_files

    except Exception as e:
        logger.error(f"切分文件 '{original_filename}' 出错: {e}", exc_info=True)
        return []

# ========= 目录扫描处理函数 =========
def process_directory_for_splitting(root_dir, max_file_size_mb):
    """扫描目录并按大小切分藏文文件"""
    max_bytes = convert_mb_to_bytes(max_file_size_mb)
    threshold = max_bytes * 0.96

    logger.info(f"开始扫描目录: {root_dir}")
    logger.info(f"文件大小限制: {max_file_size_mb:.2f} MB")

    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if not filename.lower().endswith('.txt'):
                continue
            full_path = os.path.join(dirpath, filename)
            try:
                size = os.path.getsize(full_path)
                if size > threshold:
                    logger.info(f"文件 {filename} 超出阈值，执行切分。")
                    split_text_file(full_path, max_bytes)
            except Exception as e:
                logger.error(f"处理文件 {filename} 时出错: {e}")

# ========= GUI 启动入口 =========
if __name__ == "__main__":
    try:
        root = tk.Tk()
        root.withdraw()

        messagebox.showinfo("藏文文件切分工具", "欢迎使用藏文文本切分工具！\n点击确定后选择一个包含 .txt 文件的目录。")

        folder = filedialog.askdirectory(title="请选择藏文文件所在目录")
        if not folder:
            messagebox.showwarning("操作取消", "未选择任何目录，程序已退出。")
            raise SystemExit

        max_mb = simpledialog.askfloat(
            "设置文件大小限制",
            "请输入最大单个文件大小（单位 MB）：",
            minvalue=1.0,
            initialvalue=50.0
        )
        if not max_mb:
            messagebox.showwarning("操作取消", "未输入文件大小，程序退出。")
            raise SystemExit

        process_directory_for_splitting(folder, max_mb)
        messagebox.showinfo("处理完成", f"✅ 文件切分已完成！\n日志文件：{log_filename}")

    except Exception as e:
        import traceback
        messagebox.showerror("程序出错", f"{e}\n\n{traceback.format_exc()}")
    finally:
        input("\n程序运行完毕。按 Enter 键退出...")
